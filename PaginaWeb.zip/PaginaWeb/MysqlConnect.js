var mariadb = require('mysql');



var conexion = mariadb.createConnection({
    host : 'localhost',
    database : 'web',
    user : 'admin',
    password : '2296',
});

conexion.connect(function(err) {
    if (err) {
        console.error('Connection Error: ' + err.stack);
        return;
    }
    console.log('MariaDB Successfully Connected with Identifier: ' + conexion.threadId);
});




////////////////////////////////////////////////// CONEXION CON PROCEDIMIENTOS DE MYSQL /////////////////////////////////////////////////////////////////////////


async function getTop50Words() {
    return new Promise((resolve, reject) => {
        conexion.query('SELECT name, amount FROM web.Word as data order by amount+0 desc limit 50', (err, result) => {
        if (err) {
          reject(err);
        }
        else {
            resolve(result); 
            
        }
      });
    });
}


async function getAllWords() {
    return new Promise((resolve, reject) => {
        conexion.query('SELECT name, amount FROM web.Word as data ', (err, result) => {
        if (err) {
          reject(err);
        }
        else {
         
          resolve(result);
        }
      });
    });
}


module.exports = {getTop50Words, getAllWords};


/*Probablemente necesite otra función para ecriptar strings y poder compararlos con las contraseñas encriptadas para el login*/

////////////////TEST

//InsertUser(pEmail, pFirstName, pLastname,pPassword,pGeneralDescp, pBirthdate, pPhoto, pVisibility) 
//InsertUser('Maradona@gmail.com', 'Diego','Maradona', 'CocaCola','Hago goles por comida', '1960-05-05', null, '11101110');

 //console.log( await getTop50Words()[0].name)