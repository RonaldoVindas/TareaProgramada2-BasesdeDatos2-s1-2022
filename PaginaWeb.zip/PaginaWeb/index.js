const express = require('express');
const app = express();
const path = require('path');
var mariadb = require('./MysqlConnect');


app.set('views', path.join(__dirname,'views'));

app.set('view engine','ejs');


// middlewares

//routers


    
   

app.get('/',async (req,res)=>{
    const resultado = await mariadb.getTop50Words();
    console.log(resultado[0].name)
    res.render('index', {resultado: resultado})
    
});





app.listen(3000, ()=> {
    console.log('Engine funcionando...',3000);

});